/*Jacquelyn Scheck, Roberto Andino, Collin Rijock
 * Group 7
 * COP 3530 RVC 1218
 * Assignment 1
 * 09-19-2021
 * 
 */
package Assignment1;

public interface Constants {

    public static final char LEFT_NORMAL = '(', RIGHT_NORMAL = ')';
    public static final String A_SPACE = " ";
    public static final char MULTIPLICATION = '*';
    public static final char DIVISION = '/';
    public static final char ADDITION = '+';
    public static final char SUBTRACTION = '-';

}
